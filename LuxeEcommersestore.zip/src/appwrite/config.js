import conf from "../conf/conf";
import { Client, TablesDB, ID } from "appwrite";

export class Service {
  client = new Client();
  tablesDB;

  constructor() {
    this.client
      .setEndpoint(conf.appwriteUrl)
      .setProject(conf.appwriteProjectId);
    this.tablesDB = new TablesDB(this.client);
  }

  async createCart({ product, quantity = 1 }) {
    return this.tablesDB.createRow({
      databaseId: conf.appwriteDatabaseId,
      tableId: conf.appwriteCollectionCartId,
      rowId: ID.unique(),
      data: {
        product: JSON.stringify(product),
        quantity: JSON.stringify(quantity),
      },
    });
  }

  async updateCart({ product, quantity }) {
    return this.tablesDB.updateRow({
      databaseId: conf.appwriteDatabaseId,
      tableId: conf.appwriteCollectionCartId,
      rowId: product.id,
      data: { product, quantity },
    });
  }

  async getCart({ product }) {
    return this.tablesDB.getRow({
      databaseId: conf.appwriteDatabaseId,
      tableId: conf.appwriteCollectionCartId,
      rowId: product.id,
    });
  }

  async deleteCart({ product }) {
    await this.tablesDB.deleteRow({
      databaseId: conf.appwriteDatabaseId,
      tableId: conf.appwriteCollectionCartId,
      rowId: product.id,
    });
  }

  async createWishlist({ product }) {
    return this.tablesDB.createRow({
      databaseId: conf.appwriteDatabaseId,
      tableId: conf.appwriteCollectionWishlistId,
      rowId: product.id,
      data: { product },
    });
  }

  async updateWishlist({ product }) {
    return this.tablesDB.updateRow({
      databaseId: conf.appwriteDatabaseId,
      tableId: conf.appwriteCollectionWishlistId,
      rowId: product.id,
      data: { product },
    });
  }

  async getWishlist({ product }) {
    return this.tablesDB.getRow({
      databaseId: conf.appwriteDatabaseId,
      tableId: conf.appwriteCollectionWishlistId,
      rowId: product.id,
    });
  }

  async deleteWishlist({ product }) {
    await this.tablesDB.deleteRow({
      databaseId: conf.appwriteDatabaseId,
      tableId: conf.appwriteCollectionWishlistId,
      rowId: product.id,
    });
  }
}

const service = new Service();
export default service;
